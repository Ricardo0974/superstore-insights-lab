"""Analiza el dataset Superstore 2012 con Pandas, Matplotlib y Seaborn.

Uso desde la raíz del proyecto: python src/analisis_superstore.py
Genera una figura resumen, evidencias de cada biblioteca y el resumen JSON del dashboard web.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "superstore_dataset2012.csv"
FIGURES = ROOT / "figures"
FIGURES.mkdir(exist_ok=True)

# Paleta consistente: azul/verde para valores, rojo para pérdidas y correlaciones negativas.
PALETTE = {"Furniture": "#6D8FE8", "Office Supplies": "#42B99A", "Technology": "#E7A94B"}
sns.set_theme(style="whitegrid", context="notebook", font_scale=0.9)
plt.rcParams.update({"figure.facecolor": "#F7F9FC", "axes.facecolor": "white", "axes.titleweight": "bold"})

# Carga y preparación: las fechas de origen están en formato día/mes/año.
df = pd.read_csv(DATA)
for col in ["Order Date", "Ship Date"]:
    # El archivo mezcla fechas de un dígito y de dos dígitos; dayfirst conserva el formato local.
    df[col] = pd.to_datetime(df[col], format="mixed", dayfirst=True, errors="coerce")
for col in ["Sales", "Profit", "Quantity", "Discount", "Shipping Cost"]:
    df[col] = pd.to_numeric(df[col], errors="coerce")

essential = ["Order Date", "Sales", "Profit"]
missing_essential = df[essential].isna().sum().astype(int)
rows_before = len(df)
df = df.dropna(subset=essential).copy()
dropped_rows = rows_before - len(df)
df["Año-Mes"] = df["Order Date"].dt.to_period("M").astype(str)
df["LogSales"] = np.log10(df["Sales"].clip(lower=0.01))

# Inspección reproducible: se muestran tipos, nulos y el motivo del filtrado.
print(f"Filas originales: {rows_before:,} | Filas útiles: {len(df):,} | Columnas: {df.shape[1]}")
print("\nTipos de datos:\n", df.dtypes)
nulls = df.isna().sum().loc[lambda values: values.gt(0)].sort_values(ascending=False)
print("\nNulos por columna (solo columnas con nulos):\n", nulls if not nulls.empty else "Sin nulos")
print("\nFilas descartadas por campos esenciales:\n", missing_essential)
print(f"Total descartado: {dropped_rows:,} de {rows_before:,} filas")
print(f"\nVentas: {df['Sales'].sum():,.2f} | Beneficio: {df['Profit'].sum():,.2f}")

# Datos agrupados reutilizados en gráficos y dashboard.
monthly = df.groupby("Año-Mes", observed=True)["Sales"].sum().sort_index()
sales_by_category = df.groupby("Category", observed=True)["Sales"].sum().sort_values(ascending=False)
metrics = ["Sales", "Profit", "Quantity", "Discount", "Shipping Cost"]
corr = df[metrics].corr(numeric_only=True)

# Ocho vistas en una figura: Matplotlib y Seaborn quedan visibles y diferenciados.
fig, axes = plt.subplots(3, 3, figsize=(19, 15), constrained_layout=True)
fig.suptitle("Superstore 2012 · ventas, rentabilidad y relaciones", fontsize=20, fontweight="bold")

# 1. Histograma nativo de Matplotlib: la escala logarítmica permite ver la cola de ventas.
positive_sales = df.loc[df["Sales"] > 0, "Sales"]
bins = np.logspace(np.log10(positive_sales.min()), np.log10(positive_sales.max()), 38)
plt.sca(axes[0, 0])
plt.hist(positive_sales, bins=bins, color="#496BE5", edgecolor="white", alpha=0.95)
axes[0, 0].set_xscale("log")
axes[0, 0].set(title="Matplotlib · distribución de ventas", xlabel="Ventas por pedido (escala log)", ylabel="Frecuencia")
# Conclusión: la distribución es asimétrica; muchos pedidos pequeños y pocos de importe alto.

# 2. Barras nativas de Matplotlib: suma de ventas por categoría.
plt.sca(axes[0, 1])
plt.bar(sales_by_category.index, sales_by_category.values,
        color=[PALETTE.get(name, "#8091AA") for name in sales_by_category.index], width=0.62)
axes[0, 1].set(title="Matplotlib · ventas por categoría", xlabel="Categoría", ylabel="Ventas acumuladas")
axes[0, 1].tick_params(axis="x", rotation=15)
# Conclusión: la altura compara la contribución de cada categoría al total de ventas.

# 3. Boxplot univariante de Seaborn: se omiten solo los puntos atípicos del dibujo.
sns.boxplot(data=df, x="Category", y="Profit", hue="Category", palette=PALETTE,
            legend=False, showfliers=False, ax=axes[0, 2])
axes[0, 2].set(title="Seaborn · dispersión del beneficio", xlabel="Categoría", ylabel="Beneficio por pedido")
# Conclusión: mediana y rango intercuartílico muestran diferencias de rentabilidad típica.

# 4. Dispersión bivariante nativa de Matplotlib: la línea horizontal separa ganancias y pérdidas.
plt.sca(axes[1, 0])
plt.scatter(df["Sales"], df["Profit"], alpha=0.20, s=13, color="#7757C8", edgecolors="none")
axes[1, 0].axhline(0, color="#E25462", linewidth=1.4, linestyle="--", label="Beneficio = 0")
axes[1, 0].set_xscale("log")
axes[1, 0].set(title="Matplotlib · ventas frente a beneficio", xlabel="Ventas por pedido (escala log)", ylabel="Beneficio")
axes[1, 0].legend(frameon=False, fontsize=8)
# Conclusión: existen pedidos con pérdidas a distintos niveles de venta; vender más no garantiza ganar más.

# 5. Gráfico bivariante de Seaborn: scatterplot + regplot muestran ventas y beneficio.
regression_sample = df.sample(min(1200, len(df)), random_state=12)
sns.scatterplot(data=regression_sample, x="Sales", y="Profit", ax=axes[1, 1],
                alpha=0.23, s=15, color="#42A994", edgecolor=None, label="Pedidos")
sns.regplot(data=regression_sample, x="Sales", y="Profit", logx=True, scatter=False,
            ax=axes[1, 1], line_kws={"color": "#E25462", "linewidth": 2}, ci=95)
axes[1, 1].set_xscale("log")
axes[1, 1].set(title="Seaborn · regplot ventas-beneficio",
               xlabel="Ventas por pedido (escala log)", ylabel="Beneficio")
# Conclusión: la banda representa incertidumbre del ajuste; la relación es asociación, no causalidad.

# 6. Serie temporal bivariante nativa de Matplotlib: ventas agregadas por mes.
month_positions = np.arange(len(monthly))
plt.sca(axes[1, 2])
plt.plot(month_positions, monthly.values, color="#168A78", linewidth=2.2, marker="o", markersize=3)
axes[1, 2].fill_between(month_positions, monthly.values, color="#42B99A", alpha=0.12)
axes[1, 2].set(title="Matplotlib · evolución mensual", xlabel="Mes de pedido", ylabel="Ventas del mes")
axes[1, 2].set_xticks(range(len(monthly)))
axes[1, 2].set_xticklabels(monthly.index, rotation=55, ha="right", fontsize=7)
# Conclusión: los picos destacan meses de mayor actividad comercial.

# 7. Heatmap multivariante nativo de Matplotlib (imshow + anotaciones numéricas).
mat = corr.to_numpy()
image = axes[2, 0].imshow(mat, cmap="coolwarm", vmin=-1, vmax=1, aspect="auto")
axes[2, 0].set_xticks(range(len(metrics)), labels=metrics, rotation=35, ha="right")
axes[2, 0].set_yticks(range(len(metrics)), labels=metrics)
axes[2, 0].set_title("Matplotlib · correlación numérica")
for row in range(len(metrics)):
    for col in range(len(metrics)):
        value = mat[row, col]
        axes[2, 0].text(col, row, f"{value:.2f}", ha="center", va="center",
                        color="white" if abs(value) > 0.58 else "#26354A", fontsize=8)
fig.colorbar(image, ax=axes[2, 0], fraction=0.046, pad=0.04, label="Correlación")
# Conclusión: el color y las cifras resumen asociaciones lineales, no relaciones causales.

# 8. La misma matriz multivariante con Seaborn para mostrar explícitamente ambas bibliotecas.
sns.heatmap(corr, annot=True, fmt=".2f", cmap="vlag", center=0, vmin=-1, vmax=1,
            square=True, linewidths=0.5, cbar_kws={"label": "Correlación"}, ax=axes[2, 1])
axes[2, 1].set(title="Seaborn · correlación entre métricas", xlabel="Variable", ylabel="Variable")
# Conclusión: se confirma el patrón de correlación; su lectura debe evitar inferir causalidad.

# Panel textual que guía la interpretación de las ocho visualizaciones.
axes[2, 2].axis("off")
axes[2, 2].text(0.02, 0.96, "GUÍA DE LECTURA", transform=axes[2, 2].transAxes,
                fontsize=11, fontweight="bold", color="#496BE5", va="top")
axes[2, 2].text(0.02, 0.82,
                "• Matplotlib: histograma, barras, dispersión, línea temporal y heatmap.\n\n"
                "• Seaborn: boxplot, regplot bivariante y heatmap multivariante.\n\n"
                "• Se excluyen filas sin fecha, ventas o beneficio para los gráficos.\n\n"
                "• El boxplot oculta atípicos solo en la vista; no los elimina del dataset.\n\n"
                "• Correlación y regresión describen asociación, no causalidad.",
                transform=axes[2, 2].transAxes, fontsize=10, color="#53647A", va="top", linespacing=1.35)

fig.savefig(FIGURES / "dashboard_superstore.png", dpi=180, bbox_inches="tight")
plt.close(fig)

# Evidencia independiente y fácil de localizar del gráfico bivariante hecho con Seaborn.
fig, ax = plt.subplots(figsize=(8, 6), constrained_layout=True)
sns.scatterplot(data=regression_sample, x="Sales", y="Profit", ax=ax,
                alpha=0.25, s=18, color="#42A994", edgecolor=None, label="Pedidos")
sns.regplot(data=regression_sample, x="Sales", y="Profit", logx=True, scatter=False,
            ax=ax, line_kws={"color": "#E25462", "linewidth": 2}, ci=95)
ax.set_xscale("log")
ax.set(title="Seaborn · relación bivariante de ventas y beneficio",
       xlabel="Ventas por pedido (escala log)", ylabel="Beneficio")
ax.legend(frameon=False)
fig.savefig(FIGURES / "bivariante_seaborn_regplot.png", dpi=180, bbox_inches="tight")
plt.close(fig)

# Evidencia independiente del histograma univariante nativo de Matplotlib.
fig, ax = plt.subplots(figsize=(8, 5), constrained_layout=True)
plt.sca(ax)
plt.hist(positive_sales, bins=bins, color="#496BE5", edgecolor="white", alpha=0.95)
ax.set_xscale("log")
ax.set(title="Matplotlib · histograma de ventas", xlabel="Ventas por pedido (escala log)", ylabel="Frecuencia")
fig.savefig(FIGURES / "distribucion_ventas_matplotlib.png", dpi=180, bbox_inches="tight")
plt.close(fig)

# Exportaciones independientes: ambas bibliotecas dejan una imagen multivariante auditable.
fig, ax = plt.subplots(figsize=(8, 6), constrained_layout=True)
image = ax.imshow(mat, cmap="coolwarm", vmin=-1, vmax=1)
ax.set_xticks(range(len(metrics)), labels=metrics, rotation=35, ha="right")
ax.set_yticks(range(len(metrics)), labels=metrics)
for row in range(len(metrics)):
    for col in range(len(metrics)):
        ax.text(col, row, f"{mat[row, col]:.2f}", ha="center", va="center", fontsize=9)
ax.set_title("Matplotlib · mapa de correlación")
fig.colorbar(image, ax=ax, label="Correlación")
fig.savefig(FIGURES / "heatmap_correlacion_matplotlib.png", dpi=180, bbox_inches="tight")
plt.close(fig)

fig, ax = plt.subplots(figsize=(8, 6), constrained_layout=True)
sns.heatmap(corr, annot=True, fmt=".2f", cmap="vlag", center=0, vmin=-1, vmax=1,
            square=True, linewidths=0.5, cbar_kws={"label": "Correlación"}, ax=ax)
ax.set_title("Seaborn · mapa de correlación")
fig.savefig(FIGURES / "heatmap_correlacion_seaborn.png", dpi=180, bbox_inches="tight")
plt.close(fig)

# Resumen pequeño utilizado por el dashboard web, sin descargar ni procesar el CSV en el navegador.
summary = {
    "rows": int(len(df)), "rowsBeforeFilter": int(rows_before), "droppedRows": int(dropped_rows),
    "missingEssential": {str(k): int(v) for k, v in missing_essential.items()},
    "sales": float(df["Sales"].sum()), "profit": float(df["Profit"].sum()),
    "orders": int(df["Order ID"].nunique()), "markets": int(df["Market"].nunique()),
    "years": sorted(df["Order Date"].dt.year.unique().astype(int).tolist()),
    "months": [{"month": str(k), "sales": float(v)} for k, v in monthly.items()],
    "categories": [{"name": str(k), "sales": float(v),
                    "profit": float(df.loc[df.Category.eq(k), "Profit"].sum())}
                   for k, v in df.groupby("Category", observed=True)["Sales"].sum().items()],
    "segments": [{"name": str(k), "sales": float(v)}
                 for k, v in df.groupby("Segment", observed=True)["Sales"].sum().items()],
    "regions": sorted(df["Region"].dropna().unique().astype(str).tolist()),
    "corr": corr.round(3).to_dict(),
    "scatter": df.sample(min(900, len(df)), random_state=12)[["Sales", "Profit", "Region"]].to_dict(orient="records"),
    "profitByRegion": [{"name": str(k), "profit": float(v)}
                       for k, v in df.groupby("Region", observed=True)["Profit"].sum().items()],
}
(ROOT / "data" / "resumen.json").write_text(json.dumps(summary, ensure_ascii=False), encoding="utf-8")
print("\nFiguras guardadas en figures/ y resumen web en data/resumen.json")
