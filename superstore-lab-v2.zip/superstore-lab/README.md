# Superstore Insights · Laboratorio de visualización

Dashboard interactivo y análisis reproducible del dataset **Superstore 2012**. El proyecto combina Pandas para preparar los datos, Matplotlib y Seaborn para análisis en Python, y Chart.js para explorar las vistas en una interfaz web adaptable.

## Contenido

- Dashboard con indicadores de ventas, beneficio, pedidos y mercados.
- Filtro por región y gráficos de tendencia mensual, categoría, beneficio regional, dispersión ventas-beneficio y correlaciones.
- Laboratorio para cargar CSV, XLSX o XLS, ejecutar un análisis exploratorio en el navegador, obtener gráficos y revisar una muestra de los datos.
- Exportación de informes a PDF, Word, Excel y PowerPoint, además de descarga del CSV original.
- Script Python que genera una composición con subplots y heatmaps exportables.

## Abrir en Visual Studio Code

1. Descomprime el ZIP y abre la carpeta `superstore-lab` en VS Code.
2. Abre una terminal en esa carpeta.
3. Inicia un servidor local con `python -m http.server 8000`.
4. Visita `http://localhost:8000` en el navegador. También puedes usar Live Server.

El dashboard necesita conexión a internet para cargar las bibliotecas web desde CDN. El análisis Python y las imágenes guardadas funcionan localmente una vez instaladas las dependencias.

## Análisis Python

El repositorio incluye el CSV original del ejercicio. El dashboard estático carga el resumen generado; el CSV completo se utiliza para reproducir el análisis Python.

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python src/analisis_superstore.py
```

El script crea o actualiza:

- `figures/dashboard_superstore.png`: figura 3 × 3 con ocho vistas y guía interpretativa.
- `figures/distribucion_ventas_matplotlib.png`: histograma independiente generado con `matplotlib.pyplot.hist`.
- `figures/bivariante_seaborn_regplot.png`: dispersión y tendencia bivariante de Seaborn.
- `figures/heatmap_correlacion_matplotlib.png`: heatmap multivariante construido con `imshow` y anotaciones de Matplotlib.
- `figures/heatmap_correlacion_seaborn.png`: heatmap multivariante de Seaborn.
- `data/resumen.json`: resumen que alimenta el dashboard.

### Evidencia de los criterios

| Criterio | Evidencia | Biblioteca |
|---|---|---|
| Univariante | Histograma de ventas y barras por categoría | Matplotlib |
| Univariante | Boxplot de beneficio por categoría | Seaborn |
| Bivariante | Dispersión ventas-beneficio y evolución mensual | Matplotlib |
| Bivariante | Regresión entre logaritmo de ventas y beneficio | Seaborn |
| Multivariante | Heatmap con valores anotados | Matplotlib y Seaborn |
| Composición | Figura de 3 × 3 con ocho gráficos y título general | Matplotlib/Seaborn |

En el histograma se usa escala logarítmica para mostrar pedidos de tamaños muy distintos. El boxplot oculta puntos extremos solo en la representación; esos registros siguen en el análisis. La regresión y las correlaciones describen asociaciones, no causalidad.

## Preparación y calidad de datos

El CSV incluye fechas día/mes/año, por lo que se convierten explícitamente `Order Date` y `Ship Date` con `dayfirst=True`. Se transforman las columnas numéricas relevantes con conversión tolerante a errores; el script informa tipos y nulos antes del filtrado. Solo se eliminan filas si falta alguno de los campos esenciales para las vistas: fecha de pedido, ventas o beneficio. Los nulos de otras columnas, como código postal cuando no aplica al mercado, no provocan la exclusión de la fila.

En el dataset proporcionado se procesan 4.246 filas; no se encontraron nulos en los tres campos esenciales y no se descartaron filas. Se observa que el código postal puede faltar en registros internacionales. Las fechas de envío también se convierten, aunque no se usan para excluir pedidos ni para la tendencia mensual.

## Hallazgos orientativos

- El dataset reúne 4.246 registros, 2.127 pedidos y 7 mercados.
- Las ventas agregadas rondan 1,006,427 y el beneficio neto 117,607, en las unidades monetarias originales del CSV.
- Tecnología concentra el mayor total de ventas y beneficio entre las tres categorías.
- El descuento presenta correlación negativa con el beneficio en la matriz de correlación (aprox. −0,36). Es una asociación exploratoria y no demuestra que el descuento sea por sí solo la causa.
- Noviembre es el mes con mayor venta agregada en el extracto (aprox. 134,597).

## Usar el laboratorio con otro archivo

En **Analiza otro proyecto**, suelta un archivo o usa **Elegir archivo**. Selecciona CSV, XLSX o XLS y pulsa **Ejecutar análisis**. El procesamiento ocurre en el navegador; el proyecto presenta conteo de filas y columnas, identifica una variable numérica, dibuja su distribución y una comparación por categoría cuando hay una columna categórica adecuada, y enseña una vista previa. Los botones superiores permiten exportar los resultados. Las bibliotecas de lectura y exportación se cargan desde CDN.

## Publicar en GitHub

Para publicar el dashboard como sitio estático, sube el contenido de esta carpeta a un repositorio y selecciona **Settings → Pages**; configura la rama principal y la carpeta raíz. La aplicación no requiere backend: GitHub Pages puede servir directamente `index.html`, `assets/` y `data/`.

## Estructura del proyecto

```text
superstore-lab/
├── assets/                 # estilos responsive y comportamiento del dashboard
├── data/                   # CSV original y resumen JSON
├── figures/                # figuras generadas por Python
├── src/                    # análisis reproducible
├── .vscode/tasks.json      # tarea para ejecutar el análisis desde VS Code
├── index.html              # interfaz principal
├── requirements.txt        # dependencias Python
└── README.md               # guía del proyecto
```
